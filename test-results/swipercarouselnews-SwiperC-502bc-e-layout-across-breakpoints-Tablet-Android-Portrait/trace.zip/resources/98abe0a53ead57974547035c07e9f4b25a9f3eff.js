(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_61deb162._.js",
  "static/chunks/app_(legacy)_components_719d58d3._.js",
  "static/chunks/_c34bed64._.css"
],
    source: "dynamic"
});
