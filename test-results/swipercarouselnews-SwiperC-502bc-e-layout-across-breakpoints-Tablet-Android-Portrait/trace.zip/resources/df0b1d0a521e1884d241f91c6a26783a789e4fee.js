(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/(legacy)/components/searchbox.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_9bd51ca0._.js",
  "static/chunks/app_(legacy)_components_searchbox_tsx_3295a9cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/(legacy)/components/searchbox.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/app/(legacy)/components/navbarContent.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_be5c60e9._.js",
  "static/chunks/app_(legacy)_components_navbarContent_tsx_3295a9cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/(legacy)/components/navbarContent.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/app/(legacy)/components/navbarContentMobile.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_a4f9b1f4._.js",
  "static/chunks/app_(legacy)_components_navbarContentMobile_tsx_3295a9cb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/(legacy)/components/navbarContentMobile.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);